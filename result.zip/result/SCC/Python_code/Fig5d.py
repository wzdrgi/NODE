import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

result = read_file('E:/result_pictures/result/SCC/rep1/result_scc_rep1(standardisation).txt')
result = np.array(result)
result = result.T
print(result.shape)
print(result[:,0])
result = result.tolist()
order = ['spot','x','y','ASDC',"B_Cell",'CD1C','CLEC9A','Eccrine','Endothelial_Cell','Fibroblast','Keratinocyte','LC','MDSC','Mac',
         'Melanocyte','Multiplet','NK','PDC','Pilosebaceous','TSK','Tcell','Tumor_KC_Basal','Tumor_KC_Cyc','Tumor_KC_Diff']

new_st = []
for i in range(len(order)):
    for j in range(len(result)):
        if result[j][0] == order[i]:
            new_st.append(result[j])
            break

new_st = np.array(new_st)
print(new_st[:,0])
new_st = new_st.T
print(new_st.shape)
# print(new_st[:,0])
np.savetxt('E:/result_pictures/result/SCC/rep1/result_scc_rep1(standardisation)_order.txt',new_st,fmt='%s')


