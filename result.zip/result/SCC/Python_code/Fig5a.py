import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

st_coordinates = read_file('E:/result_pictures/result/SCC/st_coordinates_rep1.txt')
st_data = read_file('E:/result_pictures/result/SCC/st_data_rep1.txt')

st_data = np.array(st_data)
st_data = st_data.T
st_data = np.delete(st_data,0,1)
st_coordinates = np.array(st_coordinates)

st_data = np.hstack((st_coordinates,st_data))

np.savetxt('E:/result_pictures/result/SCC/st_marker_rep1.txt',st_data,fmt='%s')