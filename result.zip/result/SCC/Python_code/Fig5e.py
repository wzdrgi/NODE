import numpy as np
import random

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

our_data = read_file('E:/result_pictures/result/SCC/rep1/result_scc_rep1(standardisation)_order.txt')
new_cell_list = []

a = len(our_data)
b = len(our_data[0])

for i in range(3,b):
    label = ''
    for j in range(a):
        list_mid = []
        if j == 0:
            label = our_data[j][i]
            continue
        if j != 0:
            if float(our_data[j][i]) > 0.05:
                list_mid.append(our_data[j][0])
                list_mid.append(our_data[j][1])
                list_mid.append(our_data[j][2])
                list_mid.append(label)
            else:
                continue
        new_cell_list.append(list_mid)
list_mid = ['spot','x','y','label']
new_cell_list.insert(0,list_mid)

for i in range(1,len(new_cell_list)):
    hh_1 = random.randrange(-50,50)
    hh_2 = random.randrange(-50,50)
    new_cell_list[i][1] = float(new_cell_list[i][1]) + hh_1
    new_cell_list[i][2] = float(new_cell_list[i][2]) + hh_2
    new_cell_list[i][0] = i

np.savetxt('E:/result_pictures/result/SCC/rep1/allcell_data.txt',new_cell_list,fmt='%s')