import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

scc_result = read_file('E:/result_pictures/result/SCC/rep1/result_scc_rep1(standardisation).txt')
type_name = scc_result[0]

scc_result = np.array(scc_result)
scc_result = scc_result[1:,3:]
scc_result = scc_result.T
scc_result = np.array(scc_result,dtype=np.float32)
corr = np.corrcoef(scc_result,scc_result)
corr = corr[:len(scc_result),:len(scc_result)]

def rounding(num, n=0):  
    if '.' in str(num):
        if len(str(num).split('.')[1]) > n and str(num).split('.')[1][n] == '5':
            num += 1 * 10 ** -(n+1)
    if n:
        return round(num, n)
    else:
        return round(num)

for i in range(len(corr)):
    for j in range(len(corr)):
        corr[i][j] = rounding(corr[i][j], 4)
print(corr)

type_name = type_name[3:]
type_name = np.array(type_name).reshape(-1,1)
corr = np.hstack((type_name,corr))
type_name = np.insert(type_name,0,'cell',axis=0)
type_name = type_name.reshape(1,-1)
corr = np.vstack((type_name,corr))
np.savetxt('E:/result_pictures/result/SCC/rep1/corr_cell.txt',corr,fmt='%s')