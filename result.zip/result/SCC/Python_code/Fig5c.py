import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

st_data = read_file('E:/result_pictures/result/SCC/st_data_rep1.txt')
result = read_file('E:/result_pictures/result/SCC/rep1/result_scc_rep1(standardisation).txt')

gene_name = 'MMP10'
cell_name = 'TSK'

st_data = np.array(st_data)
st_data = st_data.T

for i in range(len(result[0])):
    if result[0][i] == cell_name:
        label_cell = i
        break
for i in range(len(st_data[0])):
    if st_data[0][i] == gene_name:
        gene_label = i
        break

st_data = np.array(st_data)
result = np.array(result)

cell_vector = result[1:,label_cell]

gene_vector = st_data[1:,gene_label]

cell_vector = np.array(cell_vector,dtype=np.float32)
gene_vector = np.array(gene_vector,dtype=np.float32)

correlation_pearsonr, p_pearsonr_value = scipy.stats.pearsonr(cell_vector, gene_vector,alternative='two-sided')

print(correlation_pearsonr)