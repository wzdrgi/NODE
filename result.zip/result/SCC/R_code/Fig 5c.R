library(readxl) # 加载包
library(ggplot2)
library(tidyr)
meta<-read.table('E:/result_pictures/result/SCC/rep1/pearson_mmp10.txt',header = T,row.names = 1)
meta$spot = rownames(meta)

p <- ggplot(meta,aes(reorder(spot,-value),value))
p+geom_bar(stat = 'identity',aes(fill=spot))