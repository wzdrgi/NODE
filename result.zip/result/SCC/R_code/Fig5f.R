df<-read.table("E:/result_pictures/result/SCC/rep1/corr_cell.txt",header=T,row.names = 1)
# head(df)
library(pheatmap)
library(grid)
library(RColorBrewer)

color = brewer.pal(7,'RdYlBu')

#breaks
bk <- c(seq(-1,-0.21,by=0.001),
        seq(-0.20,0,by=0.001),
        seq(0.01,0.25,by=0.001),
        seq(0.26,1,by=0.001))
bk1 = seq(-1,-0.21,by=0.001)
bk2 = seq(-0.20,0,by=0.001)
bk3 = seq(0.01,0.25,by=0.001)
bk4 = seq(0.26,1,by=0.001)

# 做热图：
pheatmap(df,
         scale = "none",
         color = c(colorRampPalette(colors = c("#4575B4","#E0F3F8"))(length(bk1)),
                   colorRampPalette(colors = c("#E0F3F8","#FFFFBF"))(length(bk2)),
                   colorRampPalette(colors = c("#FFFFBF","#FEE090"))(length(bk3)),
                   colorRampPalette(colors = c("#FEE090","#D73027"))(length(bk4))),
         legend_breaks=seq(-1,1,1),    
         breaks=bk,
         cluster_rows=FALSE,
         cluster_cols=FALSE)