library(ggplot2)

# 文件格式：
# spot  x   y  type1 type2 type3
# s1   x1  y1  0.12  0.32   0.6
meta<-read.table('E:/result_pictures/result/SCC/rep1/allcell_data.txt',header = TRUE,row.names = 1)

head(meta)#查看前6行数据

colnames(meta)[1:2] = c('x','y')


meta$x <- (meta$x - min(meta$x))/(max(meta$x) - min(meta$x))
meta$y <- (meta$y - min(meta$y))/(max(meta$y) - min(meta$y))


mtcars.copy = meta
mtcars.copy$label = as.factor(mtcars.copy$label)

ggplot(data = mtcars.copy)+ 
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  labs(title = "MOB")+
  theme(plot.title = element_text(hjust = 0.5))+
  geom_point(aes(x = x,y = -y, color = label),size = 2.5)
#scale_size_continuous(range = c(4,4.5))