par(mfrow=c(3,1));par(mar=c(0.1,0.1,0.5,0.1));par(xaxs="i", yaxs="i")
n <- 2000

mycolors <- colorRampPalette(c("#59394B","#9A7452",'#DC8C4C','#FC4708','#F91403'), bias=1.2)(n)
barplot(rep(1,times=n),col=mycolors,border=mycolors,axes=FALSE); box()
library(ggplot2)

meta<-read.table("E:/result_pictures/result/PDAC/PDAC/result_pdac(standardisation).txt",header = TRUE,row.names = 1,check.names = FALSE)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:22]

meta$x <- (meta$x - min(meta$x))/(max(meta$x) - min(meta$x))
meta$y <- (meta$y - min(meta$y))/(max(meta$y) - min(meta$y))
#meta$MTC <- meta$MTC / max(meta$MTC)
# Atrial_cardiomyocytes 1 Ventricular_cardiom 2   Smooth_muscle_cells 3 Cardiac_neural_crest_cells 4 
ggplot(meta,aes(x = x, y = y)) + 
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  geom_point(data = meta, shape=20,aes(color= Cancer_clone_B
                                       ,size=0.5))+
  scale_size_continuous(range = c(3,4))+
  scale_colour_gradientn(colours = mycolors)