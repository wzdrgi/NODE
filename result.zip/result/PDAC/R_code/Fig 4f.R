
library(ggplot2)
library(reshape2) 
library(ggsignif)
result = read.table("E:/result_pictures/result/PDAC/PDAC/cancer and non cancer ( Manual labelling)/cancer_Cancer_clone_B.txt",header = T,check.names = F)
result_2 = read.table("E:/result_pictures/result/PDAC/PDAC/cancer and non cancer ( Manual labelling)/cancer_Cancer_clone_B.txt",header = T,check.names = F)
bp1 <- boxplot(result$Cancer_clone_B , ylim = c(0, 1.0), col = "lightblue")
par(mfrow = c(1, 2))
bp2 <- boxplot(result_2$Cancer_clone_B ,add = TRUE, col = "pink")
