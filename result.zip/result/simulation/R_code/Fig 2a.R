library(ggplot2)
library(reshape2) 
library(ggsignif)

# change the input
result = read.table("E:/result_pictures/result/simulation/Scenario 1 Replicate 1/rmse.txt",
                    header = T,
                    check.names = F)

result_box = melt(result)

ggplot(result_box,aes(x=variable,y=value,fill=variable))+
  stat_boxplot(geom = "errorbar",    # 添加误差线
               width=0.3)+
  geom_boxplot(alpha = 1,              # 透明度
               outlier.color = NULL,  # 外点颜色
               outlier.size = -1,
               outlier.alpha = NULL
  )+
  theme_bw()+                          # 白色主题
  theme(
    axis.text.x = element_text(angle = 90,
                               vjust = 0.5
    )       # x轴刻度改为倾斜90度，防止名称重叠
  )

