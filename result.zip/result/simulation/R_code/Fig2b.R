library(readxl) # 加载包
library(ggplot2)
library(tidyr)


test = read.table("E:/result_pictures/result/simulation/Scenario 1 Replicate 2/rmse_rank.txt",header = T,check.names = F)
test1 <- gather(test, E1, E2, -spot) 
ggplot(test1) +
  geom_bar(aes(x = spot, y = E2, fill = E1),
           stat = "identity") +
  labs(x = "方法", y = NULL, fill = "指标")