library(pROC)
library(ggplot2)
#全局设置小数
options(digits=3)

roc_data <- read.table('E:/result_pictures/result/simulation/Scenario 2 Replicate 1/roc_curve.txt',
                       header = T)
roc_data_replicate <- read.table('E:/result_pictures/result/simulation/Scenario 2 Replicate 1/roc_curve_replicate 2.txt',
                                 header = T)
p1=roc(response = roc_data$deconvolution, 
       predictor = roc_data$result,
       direction="<")
p2=roc(response = roc_data_replicate$deconvolution, 
       predictor = roc_data_replicate$result,
       direction="<")

plot(p1,col='red',legacy.axes=F,xlim=c(1,0),ylim=c(0,1))
plot(p2,add = TRUE,col='blue')

round(auc(p1),3)
round(auc(p2),3)

legend("bottomright", legend=c('Replicate 1 AUC-value:0.999','Replicate 2 AUC-value:0.999'),
       col=c("red","blue"),lty=1)