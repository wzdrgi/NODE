import numpy as np

def read_file(path):
    f1 = open(path)
    result_file = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        result_file.append(line)
    f1.close()
    return result_file

list_scenario = ['Scenario 1 Replicate 1','Scenario 1 Replicate 2','Scenario 2 Replicate 1','Scenario 2 Replicate 2',
        'Scenario 3 Replicate 1','Scenario 3 Replicate 2','Scenario 4 Replicate 1','Scenario 4 Replicate 2']
for i in range(len(list_scenario)):
    temp = list_scenario[i]

    rmse = read_file('E:/result_pictures/result/simulation/{}/rmse.txt'.format(temp))
    method_name = rmse[0]

    import pandas as pd

    df = pd.DataFrame(rmse)

    df = df.iloc[1:, 1:]

    rank_df = df.rank(axis=1, method='min', ascending=True)

    data_list = rank_df.values.tolist()
    method_name.pop(0)
    result_rank = [['spot','1','2','3','4','5','6']]
    for i in range(len(data_list[0])):
        count_1 = 0
        count_2 = 0
        count_3 = 0
        count_4 = 0
        count_5 = 0
        count_6 = 0
        rank_score = [method_name[i]]
        for j in range(len(data_list)):
            if data_list[j][i] == 1.0:
                count_1 = count_1 + 1
            if data_list[j][i] == 2.0:
                count_2 = count_2 + 1
            if data_list[j][i] == 3.0:
                count_3 = count_3 + 1
            if data_list[j][i] == 4.0:
                count_4 = count_4 + 1
            if data_list[j][i] == 5.0:
                count_5 = count_5 + 1
            if data_list[j][i] == 6.0:
                count_6 = count_6 + 1   

        rank_score.append(count_1/len(data_list))
        rank_score.append(count_2/len(data_list))   
        rank_score.append(count_3/len(data_list))   
        rank_score.append(count_4/len(data_list))   
        rank_score.append(count_5/len(data_list))   
        rank_score.append(count_6/len(data_list))   

        result_rank.append(rank_score)

    np.savetxt('E:/result_pictures/result/simulation/{}/rmse_rank.txt'.format(temp),result_rank,fmt='%s')   