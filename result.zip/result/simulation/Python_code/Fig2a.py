import numpy as np

# spatalk and node 
def read_file(path):
    f1 = open(path)
    result_file = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        result_file.append(line)
    f1.close()
    return result_file

def read_spotlight_file(path):
    f1 = open(path)
    result_file = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        line.pop(-1)
        result_file.append(line)
    f1.close()
    return result_file

def trans_type_name(result,stard_name):
    new_result = []
    for i in stard_name:
        for j in range(len(result)):
            if result[j][0] == i:
                new_result.append(result[j])
                break

    return np.array(new_result).T

def per_to_number(result,truth):
    for i in range(1,len(result)):
        for j in range(len(result[i])):
            result[i][j] = float(result[i][j]) * sum(truth[i-1])
    
    return result

def get_RMSE(result,truth):
    for i in range(1,len(result)):
        array_1 = np.array(result[i][3:],dtype=np.float32)
        array_2 = truth[i-1]

#reference 
list_scenario = ['Scenario 1 Replicate 1','Scenario 1 Replicate 2','Scenario 2 Replicate 1','Scenario 2 Replicate 2',
        'Scenario 3 Replicate 1','Scenario 3 Replicate 2','Scenario 4 Replicate 1','Scenario 4 Replicate 2']
for i in range(len(list_scenario)):
    temp = list_scenario[i]
    print(i)
    meta_data = read_file('E:/result_pictures/result/simulation/{}/sc_mean.txt'.format(temp))
    st_coordinaes = read_file('E:/result_pictures/result/simulation/{}/st_coordinates.txt'.format(temp))
    truth = read_file('E:/result_pictures/result/simulation/{}/truth.txt'.format(temp))

    truth.pop(0)
    for i in range(len(truth)):
        truth[i].pop(0)
    truth = np.array(truth,dtype=np.float32)
    # result
    node = read_file('E:/result_pictures/result/simulation/{}/result_our_ini.txt'.format(temp))

    type_name = meta_data[0]
    type_name.pop(0)
    type_name = ['spot','x','y'] + type_name

    node = np.array(node)
    st_coordinaes_node = np.array(st_coordinaes)[1:]
    print(st_coordinaes_node.shape,node.shape)
    node = np.hstack((st_coordinaes_node,node))
    node = node.tolist()
    node.insert(0,type_name)
    node = np.array(node)

    stard_name = node[0].tolist()
    # print(type_name)
    # other result
    spatalk = read_file('E:/result_pictures/result/simulation/{}/result_spatalk_ini.txt'.format(temp))
    spatalk = np.array(spatalk)
    spatalk = np.hstack((st_coordinaes,spatalk))
    spatalk = spatalk.T

    spatalk = trans_type_name(spatalk,stard_name=stard_name)
    # print(spatalk[0])
    # other result(percentage)
    rctd = read_file('E:/result_pictures/result/simulation/{}/result_rctd_ini.txt'.format(temp))
    seurat = read_file('E:/result_pictures/result/simulation/{}/result_seurat_ini.txt'.format(temp))
    spotlight = read_spotlight_file('E:/result_pictures/result/simulation/{}/result_spotlight_ini.txt'.format(temp))
    deconvseq = read_file('E:/result_pictures/result/simulation/{}/result_deconvseq_ini.txt'.format(temp))

    # print(truth)

    rctd = per_to_number(rctd,truth=truth)

    seurat = per_to_number(seurat,truth=truth)

    spotlight = per_to_number(spotlight,truth=truth)

    deconvseq = per_to_number(deconvseq,truth=truth)

    rctd = np.array(rctd)
    rctd = np.hstack((st_coordinaes,rctd))
    rctd = rctd.T

    seurat = np.array(seurat)
    seurat = np.hstack((st_coordinaes,seurat))
    seurat = seurat.T

    spotlight = np.array(spotlight)
    spotlight = np.hstack((st_coordinaes,spotlight))
    spotlight = spotlight.T

    deconvseq = np.array(deconvseq)
    deconvseq = np.hstack((st_coordinaes,deconvseq))
    deconvseq = deconvseq.T

    rctd = trans_type_name(rctd,stard_name=stard_name)
    seurat = trans_type_name(seurat,stard_name=stard_name)
    spotlight = trans_type_name(spotlight,stard_name=stard_name)
    deconvseq = trans_type_name(deconvseq,stard_name=stard_name)

    # print(len(node),len(spatalk),len(rctd),len(seurat),len(spotlight),len(deconvseq))

    rmse = []
    for i in range(len(node)):
        if i == 0:
            rmse.append(['spot','node','spatalk','rctd','seurat','spotlight','deconvseq'])
            continue

        array_0 = truth[i-1]
        array_1 = np.array(node[i][3:],dtype=np.float32)
        array_2 = np.array(spatalk[i][3:],dtype=np.float32)
        array_3 = np.array(rctd[i][3:],dtype=np.float32)
        array_4 = np.array(seurat[i][3:],dtype=np.float32)
        array_5 = np.array(spotlight[i][3:],dtype=np.float32)
        array_6 = np.array(deconvseq[i][3:],dtype=np.float32)

        rmse_1 = np.linalg.norm(array_1-array_0)
        rmse_2 = np.linalg.norm(array_2-array_0)
        rmse_3 = np.linalg.norm(array_3-array_0)
        rmse_4 = np.linalg.norm(array_4-array_0)
        rmse_5 = np.linalg.norm(array_5-array_0)
        rmse_6 = np.linalg.norm(array_6-array_0)

        rmse.append([node[i][0],rmse_1,rmse_2,rmse_3,rmse_4,rmse_5,rmse_6])

    np.savetxt('E:/result_pictures/result/simulation/{}/rmse.txt'.format(temp),rmse,fmt='%s')
