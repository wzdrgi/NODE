import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

w_deconvolution = read_file('E:/result_pictures/result/simulation/Scenario 4 Replicate 2/Scenario 4 Replicate 2 deconvolution.txt')
w_result = read_file('E:/result_pictures/result/simulation/Scenario 4 Replicate 2/Scenario 4 Replicate 2 result.txt')

w_deconvolution = np.array(w_deconvolution)
w_deconvolution = np.delete(w_deconvolution,0,0)
w_deconvolution = np.delete(w_deconvolution,0,1)

def get_person(w_deconvolution,w_result):
    list_deconvolution = []
    list_result = []
    for i in range(len(w_deconvolution)):
        for j in range(len(w_deconvolution[i])):
            list_deconvolution.append(w_deconvolution[i][j])
            list_result.append(w_result[i][j])
    
    array_ref = np.array(list_deconvolution,dtype=np.float32)
    array_ali = np.array(list_result,dtype=np.float32)
    correlation_pearsonr, p_pearsonr_value = scipy.stats.pearsonr(array_ref, array_ali,alternative='two-sided')
    print(correlation_pearsonr,p_pearsonr_value,'pearsonr')
    correlation_spearmanr, p_spearmanr_value = scipy.stats.spearmanr(array_ref, array_ali)
    print(correlation_spearmanr,p_spearmanr_value,'spearmanr')
    correlation_kendalltau, p_kendalltau_value = scipy.stats.kendalltau(array_ref, array_ali)
    print(correlation_kendalltau,p_kendalltau_value,'kendalltau')
    return correlation_pearsonr,correlation_spearmanr,correlation_kendalltau,p_pearsonr_value,p_spearmanr_value,p_kendalltau_value

def rounding(num, n=0):  
    if '.' in str(num):
        if len(str(num).split('.')[1]) > n and str(num).split('.')[1][n] == '5':
            num += 1 * 10 ** -(n+1)
    if n:
        return round(num, n)
    else:
        return round(num)
    
def get_roc(w_deconvolution):
    for i in range(len(w_deconvolution)):

        list_sort = []
        for j in w_deconvolution[i]:
            if float(j) != 0:
                list_sort.append(float(j))
        list_sort.sort(reverse=True)

        if len(list_sort) == 0:
            temp_number = 1
        if len(list_sort) == 1:
            max_rank = 0
            temp_number = list_sort[max_rank]
        if len(list_sort) == 2:
            max_rank = 0
            temp_number = list_sort[max_rank]
        if len(list_sort) == 3:
            max_rank = 1
            temp_number = list_sort[max_rank]
        if len(list_sort) == 4:
            max_rank = 2
            temp_number = list_sort[max_rank]

        for j in range(len(w_deconvolution[i])):
            if float(w_deconvolution[i][j]) >= temp_number:
                w_deconvolution[i][j] = 1
            else:
                w_deconvolution[i][j] = 0
    
    return w_deconvolution

correlation_pearsonr,correlation_spearmanr,correlation_kendalltau,p_pearsonr_value,p_spearmanr_value,p_kendalltau_value = get_person(w_deconvolution=w_deconvolution,w_result=w_result)
w_deconvolution_01 = get_roc(w_deconvolution)
w_result_01 = get_roc(w_result)

roc_list = [['name','deconvolution','result']]

for i in range(len(w_deconvolution_01)):
    for j in range(len(w_deconvolution_01[i])):
        list_mid = []
        list_mid.append('spot' + str(i) + str(j))
        list_mid.append(float(w_deconvolution_01[i][j]))
        list_mid.append(w_result_01[i][j])
        roc_list.append(list_mid)

roc_list_xuan = np.array(roc_list)


list_correaction = [['item','value'],
                    ['correlation_pearsonr',correlation_pearsonr],
                    ['correlation_spearmanr',correlation_spearmanr],
                    ['correlation_kendalltau',correlation_kendalltau],
                    ['1-p-value_pearsonr',1-p_pearsonr_value],
                    ['1-p-value_spearmanr',1-p_spearmanr_value],
                    ['1-p-value_kendalltau',1-p_kendalltau_value]]

np.savetxt("E:/result_pictures/result/simulation/Scenario 4 Replicate 2/" + 'roc_curve.txt',roc_list_xuan,fmt='%s')
np.savetxt('E:/result_pictures/result/simulation/Scenario 4 Replicate 2/'+'correaction.txt',list_correaction,fmt='%s')