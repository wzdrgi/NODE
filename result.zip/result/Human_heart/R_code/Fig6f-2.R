#生成调色板
par(mfrow=c(3,1));par(mar=c(0.1,0.1,0.5,0.1));par(xaxs="i", yaxs="i")
n <- 2000
mycolors <- colorRampPalette(c("#E0F2F1",'#D0EBEA','#80CBC4','#43A49B','#408d86'), bias=1.2)(n)

# 文件格式：
# spot  x   y  type1 type2 type3
# s1   x1  y1  0.12  0.32   0.6
meta<-read.table("E:/result_pictures/result/Human_heart/Human_heart/send_max_3.txt",header = TRUE,row.names = 1,check.names = FALSE)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:15]

meta$x <- (meta$x - min(meta$x))/(max(meta$x) - min(meta$x))
meta$y <- (meta$y - min(meta$y))/(max(meta$y) - min(meta$y))
#meta$MTC <- meta$MTC / max(meta$MTC)
# Atrial_cardiomyocytes 1 Ventricular_cardiom 2   Smooth_muscle_cells 3 Cardiac_neural_crest_cells 4 
ggplot(meta,aes(x = x, y = -y)) + 
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  geom_point(data = meta, shape=16,aes(color= weight
                                       ,size=1))+
  scale_size_continuous(range = c(6,8))+
  scale_colour_gradientn(colours = mycolors)

#生成调色板
par(mfrow=c(3,1));par(mar=c(0.1,0.1,0.5,0.1));par(xaxs="i", yaxs="i")
n <- 2000
mycolors <- colorRampPalette(c("#EBEB32","#D2832A",'#BD3226'), bias=1.2)(n)

# 文件格式：
# spot  x   y  type1 type2 type3
# s1   x1  y1  0.12  0.32   0.6
meta<-read.table("E:/result_pictures/result/Human_heart/Human_heart/receive_max_3.txt",header = TRUE,row.names = 1,check.names = FALSE)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:15]

meta$x <- (meta$x - min(meta$x))/(max(meta$x) - min(meta$x))
meta$y <- (meta$y - min(meta$y))/(max(meta$y) - min(meta$y))
#meta$MTC <- meta$MTC / max(meta$MTC)
# Atrial_cardiomyocytes 1 Ventricular_cardiom 2   Smooth_muscle_cells 3 Cardiac_neural_crest_cells 4 
ggplot(meta,aes(x = x, y = -y)) + 
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  geom_point(data = meta, shape=16,aes(color= weight
                                       ,size=1))+
  scale_size_continuous(range = c(6,8))+
  scale_colour_gradientn(colours = mycolors)

#生成调色板
par(mfrow=c(3,1));par(mar=c(0.1,0.1,0.5,0.1));par(xaxs="i", yaxs="i")
n <- 2000
mycolors <- colorRampPalette(c("#E0F2F1",'#D0EBEA','#80CBC4','#43A49B','#408d86'), bias=1.2)(n)

# 文件格式：
# spot  x   y  type1 type2 type3
# s1   x1  y1  0.12  0.32   0.6
meta<-read.table("E:/result_pictures/result/Human_heart/Human_heart/send_max_8.txt",header = TRUE,row.names = 1,check.names = FALSE)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:15]

meta$x <- (meta$x - min(meta$x))/(max(meta$x) - min(meta$x))
meta$y <- (meta$y - min(meta$y))/(max(meta$y) - min(meta$y))
#meta$MTC <- meta$MTC / max(meta$MTC)
# Atrial_cardiomyocytes 1 Ventricular_cardiom 2   Smooth_muscle_cells 3 Cardiac_neural_crest_cells 4 
ggplot(meta,aes(x = x, y = y)) + 
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  geom_point(data = meta, shape=16,aes(color= weight
                                       ,size=1))+
  scale_size_continuous(range = c(6,8))+
  scale_colour_gradientn(colours = mycolors)

#生成调色板
par(mfrow=c(3,1));par(mar=c(0.1,0.1,0.5,0.1));par(xaxs="i", yaxs="i")
n <- 2000
mycolors <- colorRampPalette(c("#EBEB32","#D2832A",'#BD3226'), bias=1.2)(n)

# 文件格式：
# spot  x   y  type1 type2 type3
# s1   x1  y1  0.12  0.32   0.6
meta<-read.table("E:/result_pictures/result/Human_heart/Human_heart/receive_max_8.txt",header = TRUE,row.names = 1,check.names = FALSE)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:15]

meta$x <- (meta$x - min(meta$x))/(max(meta$x) - min(meta$x))
meta$y <- (meta$y - min(meta$y))/(max(meta$y) - min(meta$y))
#meta$MTC <- meta$MTC / max(meta$MTC)
# Atrial_cardiomyocytes 1 Ventricular_cardiom 2   Smooth_muscle_cells 3 Cardiac_neural_crest_cells 4 
ggplot(meta,aes(x = x, y = y)) + 
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  geom_point(data = meta, shape=16,aes(color= weight
                                       ,size=1))+
  scale_size_continuous(range = c(6,8))+
  scale_colour_gradientn(colours = mycolors)