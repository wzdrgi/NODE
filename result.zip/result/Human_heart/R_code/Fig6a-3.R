library(Seurat)
library(ggplot2)
library(patchwork)
library(dplyr)
library(Seurat)
library(ggplot2)
library(png)
library(RImagePalette)

meta<-read.table('E:/result_pictures/result/Human_heart/Human_heart/our_deconvolution_result_16.txt',header = TRUE,row.names = 1)

head(meta)
colnames(meta)[1:2] = c('x','y')
cellname1 <- colnames(meta)[-c(1:2)][c(1:15)]

col_manual1 <- ggpubr::get_palette(palette = "default", 
                                   k = length(cellname1))####颜色
library(RColorBrewer)

#col_manual=c('#eff3ff',
# '#eff3ff',
#'#eff3ff',
#'#eff3ff',
#'#2ca25f',
#'#eff3ff',
#'#eff3ff',
#'#b30000',
#'#e34a33',
#'#fc8d59',
#'#fdbb84')
#meta2 = meta[-c(21)]

#3 1.7 1.5

ggplot2::ggplot() + scatterpie::geom_scatterpie(data = meta, 
                                                ggplot2::aes(x = x, y = y), col = cellname1, color = NA, pie_scale = 1.5) + 
  ggplot2::coord_fixed(ratio = 1) + 
  ggplot2::scale_fill_manual(values = col_manual1) + 
  ggplot2::theme_bw() + 
  ggplot2::theme(panel.grid = ggplot2::element_blank()) + 
  ggplot2::labs(x = "scaled_x", y = "scaled_y")+
  theme(panel.grid.major = element_line(color = "#F4F4F4", size = 1.2),
        panel.grid.minor = element_line(color = "#F4F4F4", size = 1.2))
#scale_x_continuous(breaks = seq(12.5, 20, by = 2.5), minor_breaks = seq(0.5, 5.5, by = 1)) +
#scale_y_continuous(breaks = seq(-21, -9, by = 3), minor_breaks = seq(-5.5, -0.5, by = 1))
