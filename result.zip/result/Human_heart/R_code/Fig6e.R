library(CellChat)
library(patchwork)
options(stringsAsFactors = FALSE)

sc_data = read.table("E:/result_pictures/result/Human_heart/Human_heart/sc_data_cellchat.txt",header = T)
sc_cell_type = read.table("E:/result_pictures/result/Human_heart/Human_heart/celltype_14_tai.txt",header = T)
rownames(sc_cell_type) = sc_cell_type[,1]
colnames(sc_cell_type)[2] <- "labels"

sc_data = normalizeData(sc_data)
cell.use = rownames(sc_cell_type)
data.input = sc_data
data.input = data.input[, cell.use]

meta = data.frame(labels = sc_cell_type$labels, row.names = colnames(data.input))
unique(meta$labels)

cellchat <- createCellChat(object = data.input, meta = meta, group.by = "labels")
levels(cellchat@idents)
groupSize <- as.numeric(table(cellchat@idents))
CellChatDB <- CellChatDB.human
showDatabaseCategory(CellChatDB)

dplyr::glimpse(CellChatDB$interaction)

CellChatDB.use <- subsetDB(CellChatDB, search = "Secreted Signaling") # use Secreted Signaling
cellchat@DB <- CellChatDB.use
cellchat <- subsetData(cellchat) # subset the expression data of signaling genes for saving computation cost
future::plan("multisession", workers = 4)

cellchat <- identifyOverExpressedGenes(cellchat)
cellchat <- identifyOverExpressedInteractions(cellchat)
cellchat <- projectData(cellchat, PPI.human)

cellchat <- computeCommunProb(cellchat, raw.use = TRUE)
# Filter out the cell-cell communication if there are only few number of cells in certain cell groups
cellchat <- filterCommunication(cellchat, min.cells = 10)

df.net <- subsetCommunication(cellchat)

cellchat <- computeCommunProbPathway(cellchat)
cellchat <- aggregateNet(cellchat)
groupSize <- as.numeric(table(cellchat@idents))
par(mfrow = c(1,2), xpd=TRUE)

a = cellchat@net$count
b = cellchat@net$weight 

mat <- cellchat@net$weight
par(mfrow = c(3,4), xpd=TRUE)
for (i in 2:3) {
  print(i)
  mat2 <- matrix(0, nrow = nrow(mat), ncol = ncol(mat), dimnames = dimnames(mat))
  print(mat2)
  mat2[i, ] <- mat[i, ]
  print(mat2)
  netVisual_circle(mat2, vertex.weight = groupSize, weight.scale = T, edge.weight.max = max(mat), title.name = rownames(mat)[i])
}

write.table(b,"E:/result_pictures/result/Human_heart/Human_heart/cell_net_weight_14.txt",row.names = T, quote = F, sep="\t")
