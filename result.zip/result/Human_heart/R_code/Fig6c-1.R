library(ggplot2)
meta<-read.table('E:/result_pictures/result/Human_heart/Human_heart/send_max_3.txt',header = TRUE,row.names = 1)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:70]

colour_breaks <- c( 0,0.40,0.42,0.46,0.6)
colours <- c("#3C4FC6","#3C4FC6","#C7D6F3",'#B50228')

ggplot(meta, aes(x = x, y = -y)) + 
  geom_point(data = meta,shape = 16,aes(color= weight,size=2))+
  scale_size_continuous(range = c(6,9))+
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  xlab(NULL)+
  ylab(NULL)+
  #scale_color_continuous(low="peachpuff",high="#3288BD")+
  scale_colour_gradientn(
    limits  = range(meta$weight),
    colours = colours[c(1, seq_along(colours), length(colours))],
    values  = c(0, scales::rescale(colour_breaks, from = range(meta$weight)), 1),
  )


meta<-read.table('E:/result_pictures/result/Human_heart/Human_heart/receive_max_3.txt',header = TRUE,row.names = 1)
head(meta)
colnames(meta)[1:2] = c('x','y')
cellname <- colnames(meta)[-c(1:2)][1:70]

colour_breaks <- c( 0,0.6,0.65,0.7,0.75,0.8)
colours <- c('#50186A',"#3E5388","#2B908A", "#6BC85F","#F4E62B")

ggplot(meta, aes(x = x, y = -y)) + 
  geom_point(data = meta,shape = 16,aes(color= weight,size=2))+
  scale_size_continuous(range = c(6,9))+
  theme_bw()+
  theme(panel.grid.major=element_line(colour=NA),
        panel.background = element_rect(fill = "transparent",colour = NA),
        plot.background = element_rect(fill = "transparent",colour = NA),
        panel.grid.minor = element_blank())+
  xlab(NULL)+
  ylab(NULL)+
  #scale_color_continuous(low="peachpuff",high="#3288BD")+
  scale_colour_gradientn(
    limits  = range(meta$weight),
    colours = colours[c(1, seq_along(colours), length(colours))],
    values  = c(0, scales::rescale(colour_breaks, from = range(meta$weight)), 1),
  )