import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

result = read_file('E:/result_pictures/result/MOB/MOB/mob_chafen_per.txt')

cellname_1 = 'PGC'
cellname_2 = 'GC'

for i in range(len(result[0])):
    if result[0][i] == cellname_1:
        label_cell_1 = i
        break
for i in range(len(result[0])):
    if result[0][i] == cellname_2:
        label_cell_2 = i
        break

result = np.array(result)

cell_vector_1 = result[1:,label_cell_1]

cell_vector_2 = result[1:,label_cell_2]

cell_vector_1 = np.array(cell_vector_1,dtype=np.float32)
cell_vector_2 = np.array(cell_vector_2,dtype=np.float32)

correlation_pearsonr, p_pearsonr_value = scipy.stats.pearsonr(cell_vector_1, cell_vector_2,alternative='two-sided')

print(correlation_pearsonr)