import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

# GC = ['n03_GC_1','n07_GC_2','n09_GC_3','n14_GC_7','n10_GC_4','n11_GC_5','n12_GC_6']
# PGC = ['n02_PGC_1','n05_PGC_2','n08_PGC_3']
# M_TC = ['n17_M_TC_3','n16_M_TC_2','n15_M_TC_1']

# MOB_result = read_file('E:/result_pictures/result/MOB/MOB/mob_chafen_per.txt')

# for i in range(len(MOB_result)):

#     if i == 0:
#         MOB_result[i].append('GC')
#         MOB_result[i].append('PGC')
#         MOB_result[i].append('M_TC')
#         continue

#     gc_count = 0
#     pgc_count = 0
#     mtc_count = 0

#     for j in range(len(MOB_result[0])):
#         if MOB_result[0][j] in GC:
#             gc_count = gc_count + float(MOB_result[i][j])
#         if MOB_result[0][j] in PGC:
#             pgc_count = pgc_count + float(MOB_result[i][j])
#         if MOB_result[0][j] in M_TC:
#             mtc_count = mtc_count + float(MOB_result[i][j])
    
#     MOB_result[i].append(gc_count)
#     MOB_result[i].append(pgc_count)
#     MOB_result[i].append(mtc_count)

# np.savetxt('')

import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

GC = ['n03_GC_1','n07_GC_2','n09_GC_3','n14_GC_7','n10_GC_4','n11_GC_5','n12_GC_6']
PGC = ['n02_PGC_1','n05_PGC_2','n08_PGC_3']
M_TC = ['n17_M_TC_3','n16_M_TC_2','n15_M_TC_1']

MOB_result = read_file('E:/result_pictures/result/MOB/MOB/deconvseq_result_per.txt')

# if the result is spotlight_light
# Please remember to replace the '.' in the first line of the name in the name of the first line and replace it with '_'

# spotlight_result = read_file('E:/result_pictures/result/MOB/MOB/spotlight_result_per.txt')
# for i in range(len(MOB_result[0])):
#     MOB_result[0][i] = MOB_result[0][i].replace('.','_')
# print(spotlight_result[0])

for i in range(len(MOB_result)):

    if i == 0:
        MOB_result[i].append('GC')
        MOB_result[i].append('PGC')
        MOB_result[i].append('M_TC')
        continue

    gc_count = 0
    pgc_count = 0
    mtc_count = 0

    for j in range(len(MOB_result[0])):
        if MOB_result[0][j] in GC:
            gc_count = gc_count + float(MOB_result[i][j])
        if MOB_result[0][j] in PGC:
            pgc_count = pgc_count + float(MOB_result[i][j])
        if MOB_result[0][j] in M_TC:
            mtc_count = mtc_count + float(MOB_result[i][j])
    
    MOB_result[i].append(gc_count)
    MOB_result[i].append(pgc_count)
    MOB_result[i].append(mtc_count)

np.savetxt('E:/result_pictures/result/MOB/MOB/deconvseq_example.txt',MOB_result,fmt='%s')