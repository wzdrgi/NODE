import numpy as np
import scipy

def read_file(path):
    f1 = open(path)
    input_data = []
    for line in f1.readlines():
        line = line.strip('\n')
        line = line.split()
        input_data.append(line)
    f1.close()
    return input_data

st_data = read_file('E:/result_pictures/result/MOB/MOB/st_marker.txt')
result = read_file('E:/result_pictures/result/MOB/MOB/mob_chafen_per.txt')

gene_name = 'Penk'
cell_name = 'GC'

for i in range(len(result[0])):
    if result[0][i] == cell_name:
        label_cell = i
        break
for i in range(len(st_data[0])):
    if st_data[0][i] == gene_name:
        gene_label = i
        break

st_data = np.array(st_data)
result = np.array(result)

cell_vector = result[:,label_cell]

gene_vector = st_data[:,gene_label]

gene_thre = 8
cell_thre = 0.15

for i in range(1,len(cell_vector)):
    if float(cell_vector[i]) < cell_thre:
        cell_vector[i] = 0.0
    else:
        cell_vector[i] = 1.0

for i in range(1,len(gene_vector)):
    if float(gene_vector[i]) < gene_thre:
        gene_vector[i] = 0
    else:
        gene_vector[i] = 1

result_save = np.hstack((st_data[:,0].reshape(-1,1),cell_vector.reshape(-1,1),gene_vector.reshape(-1,1)))
count = 0
for i in range(1,len(result_save)):
    if float(result_save[i][1]) == float(result_save[i][2]):
        count =count + 1

print(count / (len(result_save)-1))
np.savetxt('E:/result_pictures/result/MOB/MOB/Fig3e.txt',result_save,fmt='%s')