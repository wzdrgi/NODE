library(readxl) # 加载包
library(ggplot2)
library(tidyr)
meta<-read.table('E:/result_pictures/result/MOB/MOB/pcc.txt',header = T,row.names = 1)
meta$spot = rownames(meta)

p <- ggplot(meta,aes(reorder(spot,-pearson_correlation),pearson_correlation))
p+geom_bar(stat = 'identity',aes(fill=spot))