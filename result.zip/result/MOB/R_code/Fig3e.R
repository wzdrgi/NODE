library(pROC)
library(ggplot2)
#全局设置小数
options(digits=3)

roc_data <- read.table('E:/result_pictures/result/MOB/MOB/Fig3e.txt',
                       header = T)

p1=roc(response = roc_data$GC, 
       predictor = roc_data$Penk,
       direction="<")

round(auc(p1),3)
