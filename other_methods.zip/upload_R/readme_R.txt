We would be glad to provide you with the corresponding parameter settings and script files. It is worth pointing out that in the 1.0 version of SpaTalk, the interface to other deconvolution methods was already built-in so that we could call them directly. However, when I implemented the SPOTlight deconvolution method, I found that there was a problem with SpaTalk's method interface, so I found the corresponding version 0.1.7 of SPOTlight in SpaTalk and set up the script separately. In general, all methods except SPOTlight can be calculated directly by SpaTalk, and SPOTlight is a separate script. In the "Default Parameters" setting, I have only set the method's data input and the author's required parameters, but I have not changed anything else. You can see the details in the script.

Unlike NODE written in Python, these methods require us to remove 'name', 'gene', or whatever 'spot' is at the beginning of the file and replace it with a space or tab during the process of passing in the single-cell data (sc_data) and spatial transcriptome data (st_data).

When the Seurat method (i.e. method = 3), this method is applied to the human heart dataset (if you need it), the dataset size needs to be scaled up, and we deal with this by splicing multiple st_data together for an anti-convolution operation. In case of MOB, PDAC, SCC datasets, Seurat does not have any problem. Just pay attention to the tag names at the beginning of the file, as previously mentioned.


SpaTalk：1.0
RCTD(spacexr) ：2.2.0
Seurat：4.3.0
SPOTlight：0.1.7
deconvSeq：0.3.0
