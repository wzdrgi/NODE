library(SPOTlight)

st_data = read.table("E:/upload_data/developing_human_heart/final_file/st_data_1.txt",header = T,check.names = F)

sc_data = read.table("E:/upload_data/developing_human_heart/final_file/sc_data.txt",header = T)

sc_cell_type = read.table("E:/upload_data/developing_human_heart/final_file/celltype_14.txt",header = T)

ref_data<- Seurat::CreateSeuratObject(sc_data)
ref_data<- Seurat::SCTransform(ref_data, verbose = F)
Seurat::Idents(ref_data)<- sc_cell_type$celltype
cluster_markers_all <- Seurat::FindAllMarkers(object = ref_data, assay = "SCT", slot = "data", verbose = F, only.pos = TRUE)
ref_data$celltype <- sc_cell_type$celltype
spotlight_ls <- SPOTlight::spotlight_deconvolution(se_sc = ref_data, counts_spatial = as.matrix(st_data), clust_vr = "celltype", cluster_markers = cluster_markers_all)

a = spotlight_ls[[2]]

write.table(a,"E:/upload_data/developing_human_heart/final_file/result_spotlight_2.txt",row.names = F, quote = F, sep="\t")
