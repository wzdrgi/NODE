library(SpaTalk)

st_data = read.table("E:/upload_data/developing_human_heart/final_file/st_data_1.txt",header = T,check.names = FALSE)

st_data_pixel = read.table("E:/upload_data/developing_human_heart/final_file/st_data_coordinate1.txt",header = T)
rownames(st_data_pixel) = st_data_pixel[,1]

colnames(st_data_pixel)[2] <- "x"
colnames(st_data_pixel)[3] <- "y"

sc_data = read.table("E:/upload_data/developing_human_heart/final_file/sc_data.txt",header = T)

sc_cell_type = read.table("E:/upload_data/developing_human_heart/final_file/celltype_14.txt",header = T)

obj_2 <- createSpaTalk(st_data = as.matrix(st_data),
                       st_meta = st_data_pixel,
                       species = "Human",
                       if_st_is_sc = F,
                       spot_max_cell = 30)

obj <- dec_celltype(object = obj_2,
                    sc_data = as.matrix(sc_data),
                    sc_celltype = sc_cell_type$celltype,
                    method = 2)

b = data.frame(obj@coef)

write.table(b,"E:/upload_data/developing_human_heart/final_file/result_RCTD_result.txt",row.names = F, quote = F, sep="\t")
